﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Installs Bytebotd Desktop Agent from pre-baked package (PowerShell-based installer)

.DESCRIPTION
    This script runs during Windows container first boot to install the pre-baked
    Bytebotd package. It performs the same functions as an MSI installer but can be
    built entirely on Linux without WiX Toolset.

    Installation steps:
    1. Verify package exists
    2. Extract package with 7za.exe (10-30s) or Expand-Archive fallback (1-2min)
    3. Install Node.js portable
    4. Create data directories
    5. Create scheduled task for auto-start
    6. Start service immediately
    7. Wait for service to be ready
    8. Verify health check
    9. Check heartbeat file
    10. Start tray icon monitor

.NOTES
    Expected execution time: 30-60 seconds (with 7za.exe) or 60-120 seconds (fallback)
    7za.exe is bundled in C:\OEM\ (no network dependency)
    Runs as SYSTEM user during first boot
#>

[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# Set up logging
$LogDir = "C:\Bytebot-Logs"
if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}

$LogFile = Join-Path $LogDir "install-prebaked.log"
$InstallTime = Get-Date

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogMessage = "[$Timestamp] [$Level] $Message"
    Add-Content -Path $LogFile -Value $LogMessage

    switch ($Level) {
        "ERROR" { Write-Host $Message -ForegroundColor Red }
        "WARN"  { Write-Host $Message -ForegroundColor Yellow }
        "SUCCESS" { Write-Host $Message -ForegroundColor Green }
        default { Write-Host $Message -ForegroundColor Cyan }
    }
}

Write-Log "============================================"
Write-Log "   Bytebotd Pre-baked Image Installer"
Write-Log "   Started: $InstallTime"
Write-Log "============================================"
Write-Log ""

# Configuration
$PackageZip = "C:\OEM\bytebotd-prebaked.zip"
$InstallRoot = "C:\Program Files\Bytebot"
$DataDir = "C:\ProgramData\Bytebot"
$ServiceName = "Bytebotd Desktop Agent"
$HealthUrl = "http://localhost:9990/health"

# Step 1: Verify package exists
Write-Log "Step 1: Verifying package..."
if (-not (Test-Path $PackageZip)) {
    Write-Log "ERROR: Package not found at $PackageZip" "ERROR"
    Write-Log "Expected location: C:\OEM\bytebotd-prebaked.zip" "ERROR"
    exit 1
}

$PackageSize = (Get-Item $PackageZip).Length / 1MB
Write-Log "✓ Package found: $([math]::Round($PackageSize, 2))MB"
Write-Log ""

# Step 2: Extract package
Write-Log "Step 2: Extracting package to $InstallRoot..."

# Use local 7za.exe from OEM folder (bundled with installer)
$SevenZipExe = "C:\OEM\7za.exe"

if (Test-Path $InstallRoot) {
    Write-Log "Removing existing installation..." "WARN"
    Remove-Item -Recurse -Force $InstallRoot -ErrorAction SilentlyContinue
}

try {
    # Create install directory
    New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null

    # Extract ZIP (7za.exe multi-threaded or PowerShell fallback)
    $ExtractionStart = Get-Date

    if (Test-Path $SevenZipExe) {
        Write-Log "Using 7za.exe multi-threaded extraction (10-30 seconds)..."
        Write-Log "7za.exe location: $SevenZipExe"
        $Result = & $SevenZipExe x -y "-o$InstallRoot" $PackageZip 2>&1

        if ($LASTEXITCODE -ne 0) {
            Write-Log "WARN: 7za.exe extraction failed (exit code $LASTEXITCODE), falling back to Expand-Archive..." "WARN"
            Expand-Archive -Path $PackageZip -DestinationPath $InstallRoot -Force
            $ExtractionTime = ((Get-Date) - $ExtractionStart).TotalSeconds
            Write-Log "✓ Expand-Archive completed in $([math]::Round($ExtractionTime, 1))s" "SUCCESS"
        } else {
            $ExtractionTime = ((Get-Date) - $ExtractionStart).TotalSeconds
            Write-Log "✓ 7za.exe extraction completed in $([math]::Round($ExtractionTime, 1))s" "SUCCESS"
        }
    } else {
        Write-Log "WARN: 7za.exe not found at $SevenZipExe, using Expand-Archive fallback..." "WARN"
        Write-Log "Using Expand-Archive (this may take 1-2 minutes, slower fallback)..."
        Expand-Archive -Path $PackageZip -DestinationPath $InstallRoot -Force
        $ExtractionTime = ((Get-Date) - $ExtractionStart).TotalSeconds
        Write-Log "✓ Expand-Archive completed in $([math]::Round($ExtractionTime, 1))s" "SUCCESS"
    }

    # Move contents from bytebot subdirectory to root if needed
    $BytebotSubdir = Join-Path $InstallRoot "bytebot"
    if (Test-Path $BytebotSubdir) {
        Write-Log "Moving files from subdirectory..."
        Get-ChildItem -Path $BytebotSubdir | Move-Item -Destination $InstallRoot -Force
        Remove-Item -Path $BytebotSubdir -Force
    }

    Write-Log "✓ Package extracted" "SUCCESS"
} catch {
    Write-Log "ERROR: Failed to extract package: $_" "ERROR"
    exit 1
}

Write-Log ""

# Step 3: Install Node.js (portable)
Write-Log "Step 3: Installing Node.js..."

$NodeInstallPath = "C:\Program Files\nodejs"
if (-not (Test-Path $NodeInstallPath)) {
    Write-Log "Downloading Node.js portable..."
    $NodeVersion = "v20.18.1"
    $NodeUrl = "https://nodejs.org/dist/$NodeVersion/node-$NodeVersion-win-x64.zip"
    $NodeZip = Join-Path $env:TEMP "node.zip"

    try {
        # Download Node.js
        Invoke-WebRequest -Uri $NodeUrl -OutFile $NodeZip -UseBasicParsing
        Write-Log "✓ Downloaded Node.js"

        # Extract to Program Files (use local 7za.exe if available)
        if (Test-Path $SevenZipExe) {
            Write-Log "Extracting Node.js with 7za.exe..."
            & $SevenZipExe x -y "-oC:\Program Files" $NodeZip 2>&1 | Out-Null
            if ($LASTEXITCODE -ne 0) {
                Write-Log "7za.exe failed, using Expand-Archive fallback..."
                Expand-Archive -Path $NodeZip -DestinationPath "C:\Program Files" -Force
            }
        } else {
            Expand-Archive -Path $NodeZip -DestinationPath "C:\Program Files" -Force
        }

        # Rename extracted folder
        $ExtractedFolder = Join-Path "C:\Program Files" "node-$NodeVersion-win-x64"
        if (Test-Path $ExtractedFolder) {
            Rename-Item -Path $ExtractedFolder -NewName "nodejs" -Force
        }

        # Clean up
        Remove-Item $NodeZip -Force -ErrorAction SilentlyContinue

        Write-Log "✓ Node.js installed to $NodeInstallPath" "SUCCESS"
    } catch {
        Write-Log "WARN: Failed to install Node.js: $_" "WARN"
        Write-Log "Bytebotd may not start without Node.js" "WARN"
    }
} else {
    Write-Log "✓ Node.js already installed" "SUCCESS"
}

# Verify Sharp module
$BytebotdDir = Join-Path $InstallRoot "packages\bytebotd"
if (-not (Test-Path $BytebotdDir)) {
    Write-Log "ERROR: Bytebotd directory not found at $BytebotdDir" "ERROR"
    exit 1
}

$SharpPath = Join-Path $BytebotdDir "node_modules\sharp"
if (Test-Path $SharpPath) {
    Write-Log "✓ Sharp module found (pre-built for Windows)" "SUCCESS"
} else {
    Write-Log "WARN: Sharp module not found, image processing may not work" "WARN"
}

Write-Log ""

# Step 4: Create data directories
Write-Log "Step 4: Creating data directories..."

@($DataDir, $LogDir) | ForEach-Object {
    if (-not (Test-Path $_)) {
        New-Item -ItemType Directory -Path $_ -Force | Out-Null
        Write-Log "✓ Created $_"
    } else {
        Write-Log "Directory already exists: $_"
    }
}

Write-Log ""

# Step 5: Create scheduled task for auto-start
Write-Log "Step 5: Creating Windows Service (Scheduled Task)..."

$TaskName = $ServiceName
$StartScript = Join-Path $BytebotdDir "start-bytebotd.bat"
$NodeExe = Join-Path $NodeInstallPath "node.exe"

Write-Log "Batch script path: $StartScript"
Write-Log "Node.js executable: $NodeExe"

# Always create/overwrite batch file to ensure correct content
if (Test-Path $StartScript) {
    Write-Log "Overwriting existing batch file with updated content..."
} else {
    Write-Log "Creating new batch file..."
}

# Use full path to node.exe (not in PATH for SYSTEM user)
$BatchContent = @"
@echo off
cd /d "C:\Program Files\Bytebot\packages\bytebotd"
"$NodeExe" dist\main.js > "C:\Bytebot-Logs\bytebotd-stdout.log" 2>&1
"@

try {
    Set-Content -Path $StartScript -Value $BatchContent -Force -ErrorAction Stop
    Write-Log "✓ Batch file created: $StartScript" "SUCCESS"
} catch {
    Write-Log "ERROR: Failed to create batch file: $_" "ERROR"
    exit 1
}

# Verify batch file exists
if (-not (Test-Path $StartScript)) {
    Write-Log "ERROR: Batch file not found after creation: $StartScript" "ERROR"
    exit 1
}

try {
    # Delete existing task if present
    Write-Log "Removing existing scheduled task if present..."
    schtasks /delete /tn "$TaskName" /f 2>&1 | Out-Null

    # Create scheduled task using schtasks (proven to work reliably)
    Write-Log "Creating scheduled task with schtasks..."
    $Result = schtasks /create /tn "$TaskName" /tr "`"$StartScript`"" /sc onstart /ru SYSTEM /rl HIGHEST /f 2>&1

    if ($LASTEXITCODE -ne 0) {
        Write-Log "schtasks output: $Result" "ERROR"
        throw "schtasks failed with exit code $LASTEXITCODE"
    }

    Write-Log "✓ Scheduled task created: $TaskName" "SUCCESS"
} catch {
    Write-Log "ERROR: Failed to create scheduled task: $_" "ERROR"
    exit 1
}

Write-Log ""

# Step 6: Start service
Write-Log "Step 6: Starting Bytebotd service..."

try {
    Start-ScheduledTask -TaskName $TaskName
    Write-Log "✓ Service started" "SUCCESS"
} catch {
    Write-Log "ERROR: Failed to start service: $_" "ERROR"
    exit 1
}

Write-Log ""

# Step 7: Wait for service to be ready
Write-Log "Step 7: Waiting for service to be ready (30 seconds)..."
Start-Sleep -Seconds 30

Write-Log ""

# Step 8: Verify health check
Write-Log "Step 8: Verifying service health..."

$MaxAttempts = 6
$AttemptDelay = 10

for ($i = 1; $i -le $MaxAttempts; $i++) {
    Write-Log "Health check attempt $i/$MaxAttempts..."

    try {
        $Response = Invoke-WebRequest -Uri $HealthUrl -TimeoutSec 5 -UseBasicParsing
        if ($Response.StatusCode -eq 200) {
            Write-Log "✓ Service is healthy (attempt $i)" "SUCCESS"
            $ServiceHealthy = $true
            break
        }
    } catch {
        Write-Log "Service not ready yet, waiting ${AttemptDelay}s..."
        Start-Sleep -Seconds $AttemptDelay
    }
}

if (-not $ServiceHealthy) {
    Write-Log "WARN: Health check timeout after $MaxAttempts attempts" "WARN"
    Write-Log "Service may still be starting up" "WARN"
}

Write-Log ""

# Step 9: Check heartbeat file
Write-Log "Step 9: Checking heartbeat file..."

$HeartbeatFile = Join-Path $DataDir "heartbeat.txt"
if (Test-Path $HeartbeatFile) {
    $HeartbeatContent = Get-Content $HeartbeatFile -Raw
    Write-Log "✓ Heartbeat file found" "SUCCESS"
    Write-Log "Heartbeat contents:"
    Write-Log $HeartbeatContent
} else {
    Write-Log "WARN: Heartbeat file not found yet (may appear shortly)" "WARN"
}

Write-Log ""

# Step 10: Start tray icon (optional)
Write-Log "Step 10: Starting tray icon monitor..."

$TrayScript = Join-Path $InstallRoot "packages\bytebotd\bytebotd-tray.ps1"
if (Test-Path $TrayScript) {
    try {
        Start-Process powershell -ArgumentList "-WindowStyle Hidden -File `"$TrayScript`"" -NoNewWindow
        Write-Log "✓ Tray icon started" "SUCCESS"
    } catch {
        Write-Log "WARN: Failed to start tray icon: $_" "WARN"
    }
} else {
    Write-Log "Tray icon script not found, skipping"
}

Write-Log ""

# Installation summary
$InstallDuration = (Get-Date) - $InstallTime
Write-Log "============================================"
Write-Log "   Installation Complete!"
Write-Log "   Duration: $([math]::Round($InstallDuration.TotalSeconds, 1))s"
Write-Log "============================================"
Write-Log ""
Write-Log "Bytebotd Desktop Agent is now running."
Write-Log ""
Write-Log "Service status:"
Write-Log "  - Scheduled Task: $TaskName"
Write-Log "  - Port: 9990"
Write-Log "  - Logs: $LogDir"
Write-Log "  - Heartbeat: $HeartbeatFile"
Write-Log ""
Write-Log "Access points:"
Write-Log "  - Health check: http://localhost:9990/health"
Write-Log "  - Web viewer: http://localhost:8006"
Write-Log "  - RDP: localhost:3389"
Write-Log ""

exit 0
